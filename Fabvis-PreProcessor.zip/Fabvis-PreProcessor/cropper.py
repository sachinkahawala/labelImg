import cv2
import os
import PIL.Image
import numpy as np

# Set theseeeee

sourcefolderpath="source"
targetfolderpath="target"

slideHeight = 256
slideWidth = 256
jump = 36

def cropper(image, slideHeight, slideWidth, jump):
        imageH, imageW, channels = image.shape
        imageArray = []

        noOfFullH = int((imageH-slideHeight)/jump)
        noOfFullW = int((imageH-slideWidth)/jump)

        for i in range(0, noOfFullH+1):
            for j in range(0, noOfFullW+1):
                cropped = image[i*jump:(i*jump)+slideHeight, j*jump:(j*jump)+slideWidth]
                imageArray.append(cropped)

            if (imageW>((noOfFullW*jump)+slideWidth)):
                cropped = image[i*jump:(i*jump)+slideHeight, imageW-slideWidth:imageW]
                imageArray.append(cropped)

        if (imageH>((noOfFullH*jump)+slideHeight)):
            for j in range(0, noOfFullW+1):
                cropped = image[imageH-slideHeight:imageH, j*jump:(j*jump)+slideWidth]
                imageArray.append(cropped)

            if (imageW>(noOfFullW*slideWidth)):
                cropped = image[imageH-slideHeight:imageH, imageW-slideWidth:imageW]
                imageArray.append(cropped)

        return imageArray

def load_images_from_folder(folder):
    images = []
    for filename in os.listdir(folder):
        img = cv2.imread(os.path.join(folder,filename))
        if img is not None:
            images.append([img, str(filename)])

    return images

def bmpSave(filename, image):
    imagetemp = PIL.Image.fromarray(image.astype(np.uint8))
    if imagetemp.mode != 'RGB':
        imagetemp = imagetemp.convert('RGB')
        imagetemp.save(filename)

imageslist = load_images_from_folder(sourcefolderpath)

for each in imageslist:
    
    croppedArrayOfOneImage = cropper(each[0], slideHeight, slideWidth, jump)
    count = 0

    for eachImage in croppedArrayOfOneImage:
        imageName = targetfolderpath + '/' + each[1][:-4] +  '_' + str(count) + '.bmp'
        count += 1
        cv2.imwrite(imageName, eachImage)
        print(imageName)